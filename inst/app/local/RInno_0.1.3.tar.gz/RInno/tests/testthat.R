library(testthat)
library(RInno)
library(jsonlite)

test_check("RInno")
